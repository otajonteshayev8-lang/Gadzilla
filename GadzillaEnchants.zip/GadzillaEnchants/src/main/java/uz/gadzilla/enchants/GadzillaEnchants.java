package uz.gadzilla.enchants;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;

import java.util.*;

public class GadzillaEnchants extends JavaPlugin implements Listener, TabExecutor {

    enum CE {
        MOB_TAJRIBASI("mob_tajribasi", "Mob Tajribasi", 3),
        ANIQLOVCHI("aniqlovchi", "Aniqlovchi", 3),
        QON_SORUVCHI("qon_soruvchi", "Qon So'ruvchi", 2),
        ZAHAR("zahar", "Zahar", 2),
        OKSIDLANISH("oksidlanish", "Oksidlanish", 2),
        KARAXTLIK("karaxtlik", "Karaxtlik", 2),
        OGOHLANTIRUVCHI("ogohlantiruvchi", "Ogohlantiruvchi", 1);

        final String id, name;
        final int max;
        CE(String id, String name, int max) { this.id = id; this.name = name; this.max = max; }
    }

    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V"};
    private static final TextColor COLOR = TextColor.fromHexString("#8CFFD0");
    private NamespacedKey DATA, LORE_N;
    private final Random rnd = new Random();
    private final Map<String, Long> cooldowns = new HashMap<>();
    private final Map<String, Integer> counters = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        DATA = new NamespacedKey(this, "custom_enchants");
        LORE_N = new NamespacedKey(this, "lore_lines");
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("gadzilla").setExecutor(this);
        getCommand("gadzilla").setTabCompleter(this);
        getCommand("enchants").setExecutor(this);
    }

    // ---------- Ma'lumot saqlash ----------
    private boolean isSword(ItemStack it) {
        return it != null && it.getType().name().endsWith("_SWORD");
    }

    private Map<CE, Integer> read(ItemStack it) {
        Map<CE, Integer> m = new EnumMap<>(CE.class);
        if (it == null || !it.hasItemMeta()) return m;
        String s = it.getItemMeta().getPersistentDataContainer().get(DATA, PersistentDataType.STRING);
        if (s == null || s.isEmpty()) return m;
        for (String part : s.split(";")) {
            String[] kv = part.split(":");
            for (CE ce : CE.values())
                if (ce.id.equals(kv[0])) m.put(ce, Integer.parseInt(kv[1]));
        }
        return m;
    }

    private void write(ItemStack it, Map<CE, Integer> m) {
        ItemMeta meta = it.getItemMeta();
        var pdc = meta.getPersistentDataContainer();
        int old = pdc.getOrDefault(LORE_N, PersistentDataType.INTEGER, 0);
        List<Component> lore = meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
        for (int i = 0; i < old && !lore.isEmpty(); i++) lore.remove(0);
        List<Component> mine = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        for (var en : m.entrySet()) {
            mine.add(Component.text(en.getKey().name + " " + ROMAN[en.getValue()], COLOR)
                    .decoration(TextDecoration.ITALIC, false));
            if (sb.length() > 0) sb.append(";");
            sb.append(en.getKey().id).append(":").append(en.getValue());
        }
        lore.addAll(0, mine);
        if (m.isEmpty()) { pdc.remove(DATA); pdc.remove(LORE_N); }
        else { pdc.set(DATA, PersistentDataType.STRING, sb.toString()); pdc.set(LORE_N, PersistentDataType.INTEGER, mine.size()); }
        meta.lore(lore.isEmpty() ? null : lore);
        it.setItemMeta(meta);
    }

    private int lvl(Map<CE, Integer> m, CE ce) { return m.getOrDefault(ce, 0); }

    // ---------- Cooldown / hit counter ----------
    private boolean ready(Player p, CE ce, int seconds) {
        String k = p.getUniqueId() + ce.id;
        long now = System.currentTimeMillis();
        if (cooldowns.getOrDefault(k, 0L) > now) return false;
        cooldowns.put(k, now + seconds * 1000L);
        return true;
    }

    private boolean everyNth(Player p, CE ce, int n) {
        String k = p.getUniqueId() + ce.id;
        int c = counters.merge(k, 1, Integer::sum);
        if (c >= n) { counters.put(k, 0); return true; }
        return false;
    }

    private void eff(LivingEntity e, PotionEffectType t, int sec, int amp) {
        e.addPotionEffect(new PotionEffect(t, sec * 20, amp));
    }

    // ---------- Sehrlash stoli ----------
    private double chance(CE ce) { return getConfig().getDouble("chances." + ce.id, 10); }

    private Map<CE, Integer> roll() {
        Map<CE, Integer> m = new EnumMap<>(CE.class);
        for (CE ce : CE.values()) {
            for (int l = ce.max; l >= 1; l--) {
                double p = Math.min(100, chance(ce) * (1 + (ce.max - l) * 0.6));
                if (rnd.nextDouble() * 100 < p) { m.put(ce, l); break; }
            }
        }
        return m;
    }

    @EventHandler
    public void onTable(EnchantItemEvent e) {
        if (!isSword(e.getItem())) return;
        Map<CE, Integer> m = roll();
        if (m.isEmpty()) return;
        getServer().getScheduler().runTask(this, () -> {
            ItemStack it = e.getInventory().getItem(0);
            if (!isSword(it)) return;
            Map<CE, Integer> cur = read(it);
            cur.putAll(m);
            write(it, cur);
            e.getInventory().setItem(0, it);
        });
    }

    // ---------- Anvil (kitobni qilichga qo'shish) ----------
    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        AnvilInventory inv = e.getInventory();
        ItemStack a = inv.getFirstItem(), b = inv.getSecondItem();
        if (!isSword(a) || b == null || b.getType() != Material.ENCHANTED_BOOK) return;
        Map<CE, Integer> add = read(b);
        if (add.isEmpty()) return;
        ItemStack res = (e.getResult() != null && e.getResult().getType() != Material.AIR)
                ? e.getResult().clone() : a.clone();
        Map<CE, Integer> cur = read(res);
        for (var en : add.entrySet()) {
            int have = lvl(cur, en.getKey()), nw = en.getValue();
            cur.put(en.getKey(), have == nw ? Math.min(en.getKey().max, nw + 1) : Math.max(have, nw));
        }
        write(res, cur);
        e.setResult(res);
        e.getView().setRepairCost(Math.max(e.getView().getRepairCost(), 5));
    }

    // ---------- Urish effektlari ----------
    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p) || !(e.getEntity() instanceof LivingEntity v)) return;
        ItemStack it = p.getInventory().getItemInMainHand();
        if (!isSword(it)) return;
        Map<CE, Integer> m = read(it);
        if (m.isEmpty()) return;

        int l = lvl(m, CE.ANIQLOVCHI);
        if (l > 0 && ready(p, CE.ANIQLOVCHI, 10)) eff(v, PotionEffectType.GLOWING, new int[]{0, 4, 7, 10}[l], 0);

        l = lvl(m, CE.QON_SORUVCHI);
        if (l > 0 && ready(p, CE.QON_SORUVCHI, 20)) eff(p, PotionEffectType.REGENERATION, new int[]{0, 8, 15}[l], 0);

        l = lvl(m, CE.ZAHAR);
        if (l > 0 && ready(p, CE.ZAHAR, new int[]{0, 10, 7}[l])) eff(v, PotionEffectType.POISON, new int[]{0, 4, 7}[l], 0);

        l = lvl(m, CE.OKSIDLANISH);
        if (l > 0 && everyNth(p, CE.OKSIDLANISH, new int[]{0, 7, 5}[l]) && v.getEquipment() != null) {
            double pct = l == 1 ? 0.10 : 0.18;
            ItemStack[] arm = v.getEquipment().getArmorContents();
            for (int i = 0; i < arm.length; i++) {
                ItemStack a = arm[i];
                if (a == null || a.getType().getMaxDurability() <= 0) continue;
                if (a.getItemMeta() instanceof Damageable d) {
                    int max = a.getType().getMaxDurability();
                    d.setDamage(d.getDamage() + (int) (max * pct));
                    if (d.getDamage() >= max) arm[i] = null; else a.setItemMeta(d);
                }
            }
            v.getEquipment().setArmorContents(arm);
            v.getWorld().playSound(v.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.6f, 1f);
        }

        l = lvl(m, CE.KARAXTLIK);
        if (l > 0 && everyNth(p, CE.KARAXTLIK, 10)) {
            int s = l == 1 ? 2 : 4;
            eff(v, PotionEffectType.SLOWNESS, s, 9);
            eff(v, PotionEffectType.JUMP_BOOST, s, 128);
            v.getWorld().playSound(v.getLocation(), Sound.ENTITY_IRON_GOLEM_HURT, 1f, 0.6f);
        }
    }

    // ---------- Mob Tajribasi ----------
    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        if (e.getEntity() instanceof Player) return;
        Player k = e.getEntity().getKiller();
        if (k == null) return;
        int l = lvl(read(k.getInventory().getItemInMainHand()), CE.MOB_TAJRIBASI);
        if (l <= 0 || e.getDroppedExp() <= 0) return;
        double bonus = getConfig().getDouble("mob-exp-bonus-percent-per-level", 50) / 100.0;
        e.setDroppedExp((int) Math.ceil(e.getDroppedExp() * (1 + bonus * l)));
    }

    // ---------- Ogohlantiruvchi ----------
    @EventHandler
    public void onDurability(PlayerItemDamageEvent e) {
        ItemStack it = e.getItem();
        if (!isSword(it) || lvl(read(it), CE.OGOHLANTIRUVCHI) <= 0) return;
        if (!(it.getItemMeta() instanceof Damageable d)) return;
        int max = it.getType().getMaxDurability();
        int left = max - d.getDamage() - e.getDamage();
        double below = getConfig().getDouble("warn-below-percent", 10) / 100.0;
        if (left <= max * below && ready(e.getPlayer(), CE.OGOHLANTIRUVCHI, 5)) {
            e.getPlayer().sendMessage(Component.text("⚠ Qilichingiz hozir sinadi!", NamedTextColor.RED));
            e.getPlayer().sendActionBar(Component.text("⚠ Qilichingiz hozir sinadi!", NamedTextColor.RED));
            e.getPlayer().playSound(e.getPlayer().getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 0.8f);
        }
    }

    // ---------- Buyruqlar ----------
    private String desc(CE ce) {
        switch (ce) {
            case MOB_TAJRIBASI: return "Moblardan ko'proq EXP tushadi (har darajada +"
                    + (int) getConfig().getDouble("mob-exp-bonus-percent-per-level", 50) + "%).";
            case ANIQLOVCHI: return "Urganda dushmanga Glowing beradi: I-4s, II-7s, III-10s. Cooldown 10s.";
            case QON_SORUVCHI: return "Urganda sizga Regeneration beradi: I-8s, II-15s. Cooldown 20s.";
            case ZAHAR: return "Urganda dushmanga Poison beradi: I-4s (cooldown 10s), II-7s (cooldown 7s).";
            case OKSIDLANISH: return "Dushman bronyasi tezroq sinadi: I-har 7 zarbada, II-har 5 zarbada. Wither ovozi chiqadi.";
            case KARAXTLIK: return "Dushmanni karaxt qiladi: I-2s, II-4s. Har 10 zarbada.";
            default: return "Qilich joni kam qolganda \"qilichingiz hozir sinadi\" deb ogohlantiradi.";
        }
    }

    private CE find(String s) {
        String n = s.toLowerCase().replaceAll("[^a-z_]", "");
        for (CE ce : CE.values())
            if (ce.id.equals(n) || ce.id.replace("_", "").equals(n.replace("_", ""))) return ce;
        return null;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (c.getName().equals("enchants")) {
            s.sendMessage(Component.text("=== Maxsus sehrlar ===", NamedTextColor.GOLD));
            for (CE ce : CE.values())
                s.sendMessage(Component.text(ce.name + " (max " + ROMAN[ce.max] + "): ", COLOR)
                        .append(Component.text(desc(ce), NamedTextColor.GRAY)));
            return true;
        }
        if (!s.hasPermission("gadzilla.admin")) { s.sendMessage(Component.text("Ruxsat yo'q!", NamedTextColor.RED)); return true; }
        if (a.length < 4 || !a[0].equalsIgnoreCase("enchant") || !a[1].equalsIgnoreCase("give")) {
            s.sendMessage(Component.text("Ishlatilishi: /gadzilla enchant give <sehr> <daraja> [o'yinchi]", NamedTextColor.RED));
            return true;
        }
        CE ce = find(a[2]);
        if (ce == null) { s.sendMessage(Component.text("Bunday sehr yo'q! /enchants", NamedTextColor.RED)); return true; }
        int lv;
        try { lv = Integer.parseInt(a[3]); } catch (NumberFormatException ex) { lv = -1; }
        if (lv < 1 || lv > ce.max) { s.sendMessage(Component.text("Daraja 1-" + ce.max + " bo'lishi kerak.", NamedTextColor.RED)); return true; }
        Player t = a.length > 4 ? getServer().getPlayerExact(a[4]) : (s instanceof Player pl ? pl : null);
        if (t == null) { s.sendMessage(Component.text("O'yinchi topilmadi.", NamedTextColor.RED)); return true; }
        ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = book.getItemMeta();
        meta.displayName(Component.text("Maxsus sehr kitobi", COLOR).decoration(TextDecoration.ITALIC, false));
        book.setItemMeta(meta);
        Map<CE, Integer> m = new EnumMap<>(CE.class);
        m.put(ce, lv);
        write(book, m);
        t.getInventory().addItem(book).values().forEach(i -> t.getWorld().dropItem(t.getLocation(), i));
        s.sendMessage(Component.text(ce.name + " " + ROMAN[lv] + " kitobi berildi: " + t.getName(), NamedTextColor.GREEN));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (!c.getName().equals("gadzilla")) return out;
        if (a.length == 1) out.add("enchant");
        else if (a.length == 2) out.add("give");
        else if (a.length == 3) for (CE ce : CE.values()) out.add(ce.id);
        else if (a.length == 4) { CE ce = find(a[2]); if (ce != null) for (int i = 1; i <= ce.max; i++) out.add("" + i); }
        else if (a.length == 5) getServer().getOnlinePlayers().forEach(p -> out.add(p.getName()));
        String last = a[a.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }
}
